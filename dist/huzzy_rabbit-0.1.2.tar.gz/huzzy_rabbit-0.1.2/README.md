Connection

    expects a valid amqp url to connect the app to the server

Exchange 
    https://aio-pika.readthedocs.io/en/latest/rabbitmq-tutorial/3-publish-subscribe.html

Queue 

Binding 


Routing keys 

Routing Actions 